package myproject;

import java.awt.*;

import javax.swing.*;
import java.awt.event.*;
import java.util.Random;

class signupthree extends JFrame implements ActionListener {
      JLabel l1, type, card, cnumber, pin, pinnum, carddetail, pindetail, services;
      JRadioButton r1, r2, r3, r4;
      ButtonGroup grp;
      JCheckBox atm, entenetb, mobileb, emaila, checkb, estatement, condition;
      JButton submit, cancel;
      String formno;

      signupthree(String formno) {
            this.formno = formno;
            setLayout(null);
            l1 = new JLabel("Page 3 : Account Details");
            l1.setFont(new Font("Raleway", Font.BOLD, 22));
            l1.setBounds(280, 40, 400, 40);
            add(l1);

            type = new JLabel("Account Type :");
            type.setFont(new Font("Raleway", Font.BOLD, 22));
            type.setBounds(100, 140, 200, 30);
            add(type);

            r1 = new JRadioButton("Saving Account ");
            r1.setFont(new Font("Ralway", Font.BOLD, 16));
            r1.setBackground(Color.WHITE);
            r1.setBounds(100, 180, 150, 20);
            add(r1);

            r2 = new JRadioButton("Fixed Diposit Account ");
            r2.setFont(new Font("Ralway", Font.BOLD, 16));
            r2.setBackground(Color.WHITE);
            r2.setBounds(350, 180, 250, 20);
            add(r2);

            r3 = new JRadioButton("Current Account ");
            r3.setFont(new Font("Ralway", Font.BOLD, 16));
            r3.setBackground(Color.WHITE);
            r3.setBounds(100, 220, 250, 20);
            add(r3);

            r4 = new JRadioButton("Recurring Deposite Account ");
            r4.setFont(new Font("Ralway", Font.BOLD, 16));
            r4.setBackground(Color.WHITE);
            r4.setBounds(350, 220, 250, 20);
            add(r4);

            grp = new ButtonGroup();
            grp.add(r1);
            grp.add(r2);
            grp.add(r3);
            grp.add(r4);

            card = new JLabel("Card Number :");
            card.setFont(new Font("Raleway", Font.BOLD, 22));
            card.setBounds(100, 300, 200, 30);
            add(card);

            cnumber = new JLabel("xxxx-xxxx-xxxx-4164");
            cnumber.setFont(new Font("Raleway", Font.BOLD, 22));
            cnumber.setBounds(330, 300, 300, 30);
            add(cnumber);

            carddetail = new JLabel("Your 16 Digit Card Number");
            carddetail.setFont(new Font("Raleway", Font.BOLD, 16));
            carddetail.setBounds(100, 330, 300, 22);
            add(carddetail);

            pin = new JLabel("PIN Number :");
            pin.setFont(new Font("Raleway", Font.BOLD, 22));
            pin.setBounds(100, 370, 200, 30);
            add(pin);

            pinnum = new JLabel("    xxxx");
            pinnum.setFont(new Font("Raleway", Font.BOLD, 22));
            pinnum.setBounds(300, 370, 300, 30);
            add(pinnum);

            pindetail = new JLabel("Your 4 Digit Password");
            pindetail.setFont(new Font("Raleway", Font.BOLD, 16));
            pindetail.setBounds(100, 400, 300, 20);
            add(pindetail);

            services = new JLabel("Service Required :");
            services.setFont(new Font("Raleway", Font.BOLD, 22));
            services.setBounds(100, 450, 400, 30);
            add(services);

            // atm,entenetb,mobileb,emaila,checkb,estatement,condition;
            atm = new JCheckBox("ATM Card");
            atm.setBackground(Color.WHITE);
            atm.setFont(new Font("Ralway", Font.BOLD, 16));
            atm.setBounds(100, 500, 200, 30);
            add(atm);

            entenetb = new JCheckBox("Internet Bancking");
            entenetb.setBackground(Color.WHITE);
            entenetb.setFont(new Font("Ralway", Font.BOLD, 16));
            entenetb.setBounds(350, 500, 200, 30);
            add(entenetb);

            mobileb = new JCheckBox("Mobile Bancking");
            mobileb.setBackground(Color.WHITE);
            mobileb.setFont(new Font("Ralway", Font.BOLD, 16));
            mobileb.setBounds(100, 550, 200, 30);
            add(mobileb);

            emaila = new JCheckBox("Email Alert");
            emaila.setBackground(Color.WHITE);
            emaila.setFont(new Font("Ralway", Font.BOLD, 16));
            emaila.setBounds(350, 550, 200, 30);
            add(emaila);

            checkb = new JCheckBox("CheckBook");
            checkb.setBackground(Color.WHITE);
            checkb.setFont(new Font("Ralway", Font.BOLD, 16));
            checkb.setBounds(100, 600, 200, 30);
            add(checkb);

            estatement = new JCheckBox("Mobile Bancking");
            estatement.setBackground(Color.WHITE);
            estatement.setFont(new Font("Ralway", Font.BOLD, 16));
            estatement.setBounds(350, 600, 200, 30);
            add(estatement);

            condition = new JCheckBox("I hear be declare the above details are correct  to best of my knowledge");
            condition.setBackground(Color.WHITE);
            condition.setFont(new Font("Ralway", Font.BOLD, 12));
            condition.setBounds(100, 680, 600, 30);
            add(condition);

            submit = new JButton("Submit");
            submit.setBackground(Color.BLACK);
            submit.setForeground(Color.WHITE);
            submit.setFont(new Font("Ralway", Font.BOLD, 14));
            submit.setBounds(250, 720, 100, 30);
            submit.addActionListener(this);
            add(submit);

            cancel = new JButton("Cancel");
            cancel.setBackground(Color.BLACK);
            cancel.setForeground(Color.WHITE);
            cancel.setFont(new Font("Ralway", Font.BOLD, 14));
            cancel.setBounds(420, 720, 100, 30);
            cancel.addActionListener(this);
            add(cancel);

            setSize(850, 820);
            setLocation(350, 10);
            getContentPane().setBackground(Color.WHITE);
            setVisible(true);
      }

      public void actionPerformed(ActionEvent ae) {
            // TODO Auto-generated method stub
            if (ae.getSource() == submit) {
                  String accounttype = null;
                  if (r1.isSelected()) {
                        accounttype = "Saving Account";
                  } else if (r2.isSelected()) {
                        accounttype = "Fixed Deposit Account";
                  } else if (r3.isSelected()) {
                        accounttype = "Current Account";
                  } else if (r4.isSelected()) {
                        accounttype = "Recurring Deposite Account";
                  }
                  Random rnd = new Random();
                  String cardnumber = "" + Math.abs((rnd.nextLong() % 90000000L) + 504093600000000L);
                  String pinnumber = "" + Math.abs((rnd.nextLong() % 9000L) + 1000L);
                  String facility = "";
                  // atm,entenetb,mobileb,emaila,checkb,estatement,condition;
                  if (atm.isSelected()) {
                        facility = facility + "ATM Card";
                  } else if (entenetb.isSelected()) {
                        facility = facility + "Enternet Bancking";
                  } else if (mobileb.isSelected()) {
                        facility = facility + "Mobile Banking";
                  } else if (emaila.isSelected()) {
                        facility = facility + "Email Alerts";
                  } else if (checkb.isSelected()) {
                        facility = facility + "Check Book";
                  } else if (estatement.isSelected()) {
                        facility = facility + "E-Statement";
                  }
                  try {
                        if (accounttype.equals("")) {
                              JOptionPane.showMessageDialog(null, "Account Type is Mendetory");

                        } else {
                              con11 c = new con11();
                              String q1 = "insert into signupthree values('" + formno + "','" + accounttype + "','"
                                          + cardnumber + "','" + pinnumber + "','" + facility + "')";
                              c.s.executeUpdate(q1);

                              String q2 = "insert into login values('" + formno + "','" + cardnumber + "','" + pinnumber
                                          + "')";
                              c.s.executeUpdate(q2);

                              JOptionPane.showMessageDialog(null, "Card NO :" + cardnumber + "\n Pin NO:" + pinnumber);
                            setVisible(false);
                              new deposit(pinnumber).setVisible(true);
                        }

                  } catch (Exception e) {
                        System.out.println(e);
                  }
            } else if (ae.getSource() == cancel) {
                  setVisible(false);
                  new login().setVisible(true);
            }

      }

      public static void main(String[] args) {
            new signupthree("");
      }

}