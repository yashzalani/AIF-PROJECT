package myproject;

import java.sql.*;

public class con11 {
      Connection c;
      Statement s;

      public con11() {
            try {
                  //Class.forName(com.mysql.cj.jdbc.Driver);
                  c = DriverManager.getConnection("jdbc:mysql://localhost/bankmanagementsystem", "root", "password");
                  s = c.createStatement();
            } catch (Exception e) {
                  System.out.println(e);
            }
      }

}
