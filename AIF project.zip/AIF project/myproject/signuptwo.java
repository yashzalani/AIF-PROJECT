package myproject;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
 class signuptwo extends JFrame  implements ActionListener{
      JLabel educationl,  additionaldetail, categjl, incomjl, occupation, education, qualifications, eaccount, pannum, adharnum,scity;
      JTextField adhartf, pantf;
      JButton next;
      JRadioButton syes, sno, eyes, eno;
      ButtonGroup sbgroup, ebgroup;
      JComboBox relegion,categorycombo,incomcombo,educationtf,qualificationscombo,occucombo;
     String formno;
      signuptwo(String formno) {
            this.formno=formno;
            setTitle("Signup Page");
            setLayout(null);
           

            

            additionaldetail = new JLabel("Page 2:Additional Details");
            additionaldetail.setFont(new Font("Ralway", Font.BOLD, 22));
            additionaldetail.setBounds(290, 80, 400, 30);
            add( additionaldetail);

            educationl = new JLabel("Religion :");
            educationl.setFont(new Font("Ralway", Font.BOLD, 20));
            educationl.setBounds(100, 140, 100, 30);
            add(educationl);
            
            String religionarr[]={"Hindu","Muslim","Christian","sikh","Others"};
            relegion=new JComboBox(religionarr);
            relegion.setBounds(300, 140, 400, 30);
            relegion.setBackground(Color.WHITE);
            add(relegion);


            categjl = new JLabel("Category :");
            categjl.setFont(new Font("Ralway", Font.BOLD, 20));
            categjl.setBounds(100, 190, 200, 30);
            add(categjl);

            String category[]={"Open","OBC","NT","SC","Others"};
            categorycombo=new JComboBox(category);
            categorycombo.setBounds(300, 190, 400, 30);
            categorycombo.setBackground(Color.WHITE);
            add(categorycombo);

            incomjl = new JLabel("Income:");
            incomjl.setFont(new Font("Ralway", Font.BOLD, 20));
            incomjl.setBounds(100, 240, 200, 30);
            add(incomjl);

            String incom []={"Less than 1L","up to 1L","up to 3L","up to 5L","up to 10L"};
            incomcombo =new JComboBox(incom);
            incomcombo.setBounds(300, 240, 400, 30);
            incomcombo.setBackground(Color.WHITE);;
            add(incomcombo);

            education = new JLabel("Education :");
            education.setFont(new Font("Ralway", Font.BOLD, 20));
            education.setBounds(100, 290, 200, 30);
            add(education);

            String educationdetail []={"Graguate","Undergraduate","Postgraduate","Farmer","Others"};
            educationtf=new JComboBox(educationdetail);
            educationtf.setBounds(300, 290, 400, 30);
            educationtf.setBackground(Color.WHITE);
            add(educationtf);

            qualifications = new JLabel("Qualifications :");
            qualifications.setFont(new Font("Ralway", Font.BOLD, 20));
            qualifications.setBounds(100, 340, 200, 30);
            add(qualifications);

            String qualifi[]={"10th","12th"};
            qualificationscombo = new JComboBox(qualifi);
            qualificationscombo.setFont(new Font("Ralway", Font.BOLD, 14));
            qualificationscombo.setBounds(300, 340, 400, 30);
            qualificationscombo.setBackground(Color.WHITE);
            add(qualificationscombo);

            occupation = new JLabel("Occupation :");
            occupation.setFont(new Font("Ralway", Font.BOLD, 20));
            occupation.setBounds(100, 390, 200, 30);
            add(occupation);

            String occuarr []={"Student","Bussunessman","Farmer","Employee","Others"};
            occucombo=new JComboBox(occuarr);
            occucombo.setBounds(300,390,400,30);
            occucombo.setBackground(Color.WHITE);
            add(occucombo);
          
            

           

            pannum= new JLabel("PAN Number :");
            pannum.setFont(new Font("Ralway", Font.BOLD, 20));
            pannum.setBounds(100, 440, 200, 30);
            add(pannum);

            pantf = new JTextField();
            pantf.setFont(new Font("Ralway", Font.BOLD, 14));
            pantf.setBounds(300, 440, 400, 30);
            add(pantf);

            adharnum = new JLabel("Adhar Number :");
            adharnum.setFont(new Font("Ralway", Font.BOLD, 20));
            adharnum.setBounds(100, 490, 200, 30);
            add(adharnum);

            adhartf = new JTextField();
            adhartf.setFont(new Font("Ralway", Font.BOLD, 14));
            adhartf.setBounds(300, 490, 400, 30);
            add(adhartf);

            scity = new JLabel("Seneour citizen :");
            scity.setFont(new Font("Ralway", Font.BOLD, 20));
            scity.setBounds(100, 540, 200, 30);
            add(scity);

            syes = new JRadioButton("Yes");
            syes.setBounds(300, 540, 60, 30);
            syes.setBackground(Color.WHITE);
            add(syes);

            sno = new JRadioButton("NO");
            sno.setBounds(480, 540, 60, 30);
            sno.setBackground(Color.WHITE);
            add(sno);

            sbgroup=new ButtonGroup();
            sbgroup.add(syes);
            sbgroup.add(sno);

            eaccount = new JLabel("Existing Account :");
            eaccount.setFont(new Font("Ralway", Font.BOLD, 20));
            eaccount.setBounds(100, 590, 200, 30);
            add( eaccount);

            eyes = new JRadioButton("Yes");
            eyes.setFont(new Font("Ralway", Font.BOLD, 14));
            eyes.setBounds(300, 590, 60, 30);
            eyes.setBackground(Color.WHITE);
            add(eyes);

            eno = new JRadioButton("No");
            eno.setFont(new Font("Ralway", Font.BOLD, 14));
            eno.setBounds(480, 590, 60, 30);
            eno.setBackground(Color.WHITE);
            add(eno);

            ebgroup=new ButtonGroup();
            ebgroup.add(eyes);
            ebgroup.add(eno);

            next = new JButton("Next");
            next.setBackground(Color.BLACK);
            next.setForeground(Color.WHITE);
            next.setFont(new Font("Ralway", Font.BOLD, 14));
            next.setBounds(620, 660, 80, 30);
            next.addActionListener(this);
            add(next);

            getContentPane().setBackground(Color.WHITE);
            setSize(850, 800);
            setLocation(350, 10);
            setVisible(true);
      }
      public void actionPerformed(ActionEvent ae)
      {
      
        String sreligion=(String)relegion.getSelectedItem();
       String scategory=(String)categorycombo.getSelectedItem();
        String sincome=(String)incomcombo.getSelectedItem();
        String seducation=(String)educationtf.getSelectedItem();
        String squalification=(String)qualificationscombo.getSelectedItem();
        String soccupation=(String)occucombo.getSelectedItem();
        String pan=pantf.getText();
        String adhar=adhartf.getText();
        String seniurcityzen=null;
        if(syes.isSelected())
        {
            seniurcityzen="Yes";
        }
       else if(sno.isSelected())
        {
            seniurcityzen="NO";
        }
        String existingaccount=null;
       if(eyes.isSelected())
        {
            existingaccount="Yes";
        }
      else if(eno.isSelected())
        {
            existingaccount="NO";
        }
       
       
        try {
            if(adhar.equals(""))
            {
                  JOptionPane.showMessageDialog(null, "Adhar is Required");

            }else
            {
                  con11 c=new con11();
                 String query="insert into signuptwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+seducation+"','"+squalification+"','"+soccupation+"','"+seniurcityzen+"','"+existingaccount+"','"+pan+"','"+adhar+"')";

                 c.s.executeUpdate(query);
                 setVisible(true);
                 new signupthree(formno).setVisible(true);
            }
        } catch (Exception e) {
          System.out.println(e);
        }
        
      }
      
      public static void main(String[] args) {
            new signuptwo("");
      }
}

